
window.lazySizesConfig = window.lazySizesConfig || {};

window.lazySizesConfig.lazyClass = 'jch-lazyload';
window.lazySizesConfig.preloadClass = 'jch-prelazyload';
window.lazySizesConfig.loadingClass = 'jch-lazyloading';
window.lazySizesConfig.loadedClass = 'jch-lazyloaded';
window.lazySizesConfig.loadMode = 1;


