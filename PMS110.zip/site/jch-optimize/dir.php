<?php
           
$DIR = 'C:\xampp\htdocs\orginal/';
           