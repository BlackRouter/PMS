import platform , distro



print("""
Linux distribution: %s
Platform: %s
""" % (
distro.linux_distribution(full_distribution_name=False),
platform.platform(),

))